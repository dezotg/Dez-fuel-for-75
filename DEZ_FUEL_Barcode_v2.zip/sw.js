const CACHE='dez-fuel-barcode-v2';
const ASSETS=['./','./index.html','./manifest.webmanifest'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{
  if(e.request.url.includes('openfoodfacts.org') || e.request.url.includes('unpkg.com')) return;
  e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)));
});
